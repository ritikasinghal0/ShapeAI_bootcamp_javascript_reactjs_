import React from "react";

function Note(){
  return (
    <div>
      <h1>javascript and react.js</h1>
      <p> this was an amazing bootcamp taken by shaurya sir. we learnt everything from scatch
        </p>
      </div>
  );
}

export default Note;